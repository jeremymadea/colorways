These demo notebooks show how to use the colorways library. 

Jupyter notebook must be installed and ipywidgets and ipycanvas are required 
for them to work. 
